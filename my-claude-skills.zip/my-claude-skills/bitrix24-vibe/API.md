# Bitrix24 Vibe — что доступно программно

## На 17.04.2026 — публичного REST для Vibe нет

Всё, что вы делаете в конструкторе Vibe, под капотом откладывается в:

- Шаблоны бизнес-процессов (`bp_workflow_template`)
- Роботов CRM (`crm_automation_robot`)
- Smart-процессы (`crm_dynamic_type`)
- Формы CRM (`crm_webform`)
- Триггеры (`crm_trigger`)

К ним **есть** REST — через скилл `bitrix24-api`:

## Биз-процессы (`bizproc.*`)

| Метод | Назначение |
|---|---|
| `bizproc.workflow.template.list` | Список шаблонов |
| `bizproc.workflow.template.add` | Создать шаблон (XML-спецификация процесса) |
| `bizproc.workflow.template.update` | Обновить |
| `bizproc.workflow.template.delete` | Удалить |
| `bizproc.workflow.instance.list` | Запущенные экземпляры |
| `bizproc.workflow.start` | Запустить БП на сущности |
| `bizproc.activity.add` | Зарегистрировать кастомную активити |
| `bizproc.robot.add` | Зарегистрировать робота |

## Smart-процессы

| Метод | Назначение |
|---|---|
| `crm.type.add` | Создать smart-процесс |
| `crm.type.list` | Список |
| `crm.item.add` (entityTypeId) | Создать элемент smart-процесса |
| `crm.category.*` | Воронки внутри smart-процесса |

## Формы (CRM Webform)

| Метод | Назначение |
|---|---|
| `crm.webform.list` | Список форм |
| `crm.webform.update` | Обновить форму |
| `crm.webform.fieldType` | Типы полей |

## Триггеры (automation)

Триггеры редактируются только через UI/Vibe-промпт. Чтение — через `crm.automation.trigger.list` (если включено тарифом).

## Ссылки

- https://apidocs.bitrix24.com/api-reference/bizproc/
- https://apidocs.bitrix24.com/api-reference/crm/dynamic/
- https://apidocs.bitrix24.com/api-reference/crm/webform/
