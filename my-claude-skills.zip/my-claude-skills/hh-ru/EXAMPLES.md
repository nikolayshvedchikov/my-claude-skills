# hh.ru — примеры

## 0. Зависимости

```bash
pip install httpx python-dotenv
```

## 1. Поиск вакансий "Python" в Москве за последний день

```python
import os, httpx
from dotenv import load_dotenv
load_dotenv()

H = {"User-Agent": "MyBot/1.0 (n@extravert.bz)"}

r = httpx.get("https://api.hh.ru/vacancies", params={
    "text": "Python", "area": 1, "per_page": 50, "period": 1,
}, headers=H)
for v in r.json()["items"]:
    s = v.get("salary") or {}
    print(v["id"], v["name"], v["employer"]["name"],
          f'{s.get("from","?")}-{s.get("to","?")} {s.get("currency","")}')
```

## 2. Получить новые отклики работодателя

```python
tok = os.environ["HH_ACCESS_TOKEN"]
eid = os.environ["HH_EMPLOYER_ID"]
H = {"Authorization": f"Bearer {tok}",
     "User-Agent": "MyBot/1.0 (n@extravert.bz)"}

actives = httpx.get(
    f"https://api.hh.ru/employers/{eid}/vacancies/active",
    headers=H).json()
for v in actives["items"]:
    neg = httpx.get("https://api.hh.ru/negotiations",
        params={"vacancy_id": v["id"], "per_page": 100, "order_by": "created_at"},
        headers=H).json()
    for n in neg["items"]:
        if n["state"]["id"] == "response":
            print("Новый отклик:", n["resume"]["last_name"], "на", v["name"])
```

## 3. Refresh access token

```python
r = httpx.post("https://hh.ru/oauth/token", data={
    "grant_type": "refresh_token",
    "refresh_token": os.environ["HH_REFRESH_TOKEN"],
}).json()
# r = {"access_token": "...", "refresh_token": "...", "expires_in": 1209600}
```

## 4. Массовая синхронизация откликов в CSV

```python
import csv
with open("new_responses.csv", "w", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["vacancy", "resume_id", "applicant", "created_at"])
    for v in actives["items"]:
        for n in httpx.get("https://api.hh.ru/negotiations",
                           params={"vacancy_id": v["id"], "per_page": 100},
                           headers=H).json()["items"]:
            w.writerow([v["name"], n["resume"]["id"],
                       f'{n["resume"]["first_name"]} {n["resume"]["last_name"]}',
                       n["created_at"]])
```

## 5. Ответить соискателю (только по подтверждению пользователя!)

```python
# После явного «да» от пользователя и утверждения текста
text = "Здравствуйте! Спасибо за отклик. Можем ли мы созвониться завтра в 15:00?"
httpx.put(
    f"https://api.hh.ru/negotiations/active/{negotiation_id}/messages",
    headers=H,
    json={"message": text})
```
