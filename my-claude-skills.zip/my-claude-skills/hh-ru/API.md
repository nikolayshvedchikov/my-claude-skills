# hh.ru API — справочник методов

## Заголовки для всех запросов
```
Authorization: Bearer <HH_ACCESS_TOKEN>
User-Agent: MyApp/1.0 (contact@example.com)
Accept: application/json
```

## Поиск вакансий

### GET /vacancies
Параметры:
- `text` — поисковая строка (`"Python разработчик"`)
- `area` — ID региона (1 = Москва, 2 = СПб; полный список `/areas`)
- `salary` — зарплата от
- `only_with_salary=true`
- `experience` — `noExperience|between1And3|between3And6|moreThan6`
- `employment` — `full|part|project|volunteer|probation`
- `schedule` — `fullDay|shift|flexible|remote|flyInFlyOut`
- `per_page` — до 100
- `page` — 0..19

## Вакансии работодателя

### GET /employers/{employer_id}/vacancies/active
Список активных.

### POST /vacancies
Создать/опубликовать. Обязательные поля: `name`, `area`, `description`, `employment`, `professional_roles[]`, `billing_type`, `schedule`.

### PUT /vacancies/{id}
Обновить.

### DELETE /vacancies/{id}
Архивировать.

## Отклики (negotiations)

### GET /negotiations
Свои отклики — для соискателя. Для работодателя: `/negotiations?vacancy_id={id}`.

Статусы (`state`): `response`, `invitation`, `discard`, `hired`, `canceled`, и т.д.

### GET /negotiations/{id}
Детали отклика.

### PUT /negotiations/active/{id}/messages
Ответить соискателю.

### PUT /negotiations/{id}/discard
Отклонить (**опасное, нужна явная конфирмация пользователем**).

### PUT /negotiations/{id}/invite
Пригласить (нужна конфирмация).

## Резюме

### GET /resumes/mine
Свои резюме.

### GET /resumes/{id}
Работодателем — просмотр по оплате контактов.

### GET /resumes/{id}/views
История просмотров.

## Справочники

### GET /areas
Дерево регионов (рекурсивно).

### GET /dictionaries
Всё что нужно для UI: валюты, типы занятости, языки, график.

### GET /professional_roles
Профессиональные роли (нужны при публикации вакансии).

## Коды ошибок

| HTTP | Что делать |
|---|---|
| 400 | Ошибка валидации — читать `errors[]` |
| 401 | Токен истёк — refresh |
| 403 | Нет прав (тариф / User-Agent) |
| 404 | Ресурс не существует |
| 429 | Rate-limit — expo backoff |
