# my-claude-skills

Репозиторий-каркас для Claude-скиллов под ключевые направления работы: **Bitrix24 (API и вайб-код платформа), Avito, 1С Фреш, hh.ru, Getcourse**.

> Подготовлено для приватного GitHub-репозитория. Структура следует формату Claude Skill: каждая папка содержит `SKILL.md` (описание + инструкции для Claude) и сопутствующие справочные материалы.

## Структура

```
my-claude-skills/
├── README.md                  # этот файл
├── .gitignore                 # исключает реальные .env и секреты
├── .env.example               # шаблон переменных окружения для всех интеграций
├── STATUS.md                  # таблица: что есть / что знаю / чего нет
├── bitrix24-api/              # REST API Bitrix24 (webhooks + OAuth)
├── bitrix24-vibe/             # Bitrix24 Вайб-код платформа (low-code)
├── avito/                     # Avito.ru (Messenger API / объявления / автозагрузка)
├── 1c-fresh/                  # 1С:Фреш (управление пользователями, конфигурациями)
├── hh-ru/                     # hh.ru API (вакансии, отклики, резюме)
└── getcourse/                 # Getcourse.ru API (пользователи, заказы, письма)
```

## Как загрузить в приватный GitHub

```bash
cd my-claude-skills
git init
git add .
git commit -m "Initial skill scaffolds"
gh repo create my-claude-skills --private --source=. --remote=origin --push
# или, если gh CLI не установлен:
git remote add origin https://github.com/<USER>/my-claude-skills.git
git push -u origin main
```

## Безопасность credentials

**Рекомендация:** даже в приватном репозитории не коммитить реальные ключи напрямую. Используйте один из вариантов:

1. **`.env` локально + `.gitignore`** (по умолчанию в этом репо). Реальные ключи вы храните на своей машине; в репо — только `.env.example`.
2. **GitHub Secrets** (если будете использовать Actions): Settings → Secrets and variables → Actions.
3. **Менеджер секретов** (1Password, Doppler, Vault) — с подстановкой значений через CI/CD.

Если вы всё же решите класть реальные ключи прямо в `.env` репозитория — убедитесь, что репозиторий **приватный**, и вы понимаете, что утечка токена Bitrix24 webhook даёт полный доступ к порталу.

## Формат каждого скилла

В каждой папке:

- `SKILL.md` — описание скилла по стандарту Claude (frontmatter + тело)
- `API.md` — справочник по API сервиса: endpoints, auth, rate limits, ссылки на доки
- `EXAMPLES.md` — типовые сценарии и заготовки запросов
- `.env.example` (где применимо) — переменные для данного сервиса

## Использование с Claude (Cowork / Claude Code / Desktop)

Чтобы Claude подхватывал скиллы:

- **Cowork / Claude Desktop**: скопировать содержимое `my-claude-skills/<skill>/` в `~/Library/Application Support/Claude/.claude/skills/<skill>/` (macOS) или аналогичный путь (см. доку Claude).
- **Claude Code**: положить скилл в `.claude/skills/<skill>/` внутри вашего проекта, либо использовать плагин-маркетплейс.

Alternatively — собрать `.skill` архив (zip папки с SKILL.md внутри) и «перетащить» в Claude.
