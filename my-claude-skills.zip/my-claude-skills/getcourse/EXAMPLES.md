# Getcourse — примеры

## 0. Зависимости
```bash
pip install requests python-dotenv
```

## 1. Создать/обновить пользователя с тегом

```python
import os, json, base64, requests
from dotenv import load_dotenv
load_dotenv()

data = {
    "user": {
        "email": "ivanov@example.com",
        "first_name": "Иван",
        "last_name": "Иванов",
        "phone": "+79998887766",
        "group_name": ["Оплатил-2026", "Новогодняя-акция"]
    },
    "system": {"refresh_if_exists": 1}
}
encoded = base64.b64encode(json.dumps(data).encode()).decode()
r = requests.post(f"{os.environ['GETCOURSE_API_BASE']}/users",
                  data={"action": "add",
                        "key": os.environ["GETCOURSE_SECRET_KEY"],
                        "data": encoded})
print(r.json())
```

## 2. Экспорт пользователей с фильтром

```python
base = os.environ["GETCOURSE_API_BASE"]
key = os.environ["GETCOURSE_SECRET_KEY"]

# Запустить экспорт
r = requests.post(f"{base}/account/users", data={
    "key": key,
    "params[status]": "paid",
    "params[created_at][from]": "2026-01-01",
    "params[created_at][to]": "2026-04-17",
}).json()
export_id = r["info"]["export_id"]

# Дождаться и забрать
import time
while True:
    res = requests.get(f"{base}/account/exports/{export_id}",
                       params={"key": key}).json()
    if res["info"]["status"] == "done":
        break
    time.sleep(5)

items = res["info"]["items"]
fields = res["info"]["fields"]
for row in items[:5]:
    print(dict(zip(fields, row)))
```

## 3. Создать заказ через API

```python
deal = {
    "user": {"email": "new@example.com", "first_name": "Новый"},
    "system": {"refresh_if_exists": 1},
    "deal": {
        "deal_number": "2026-1001",
        "deal_status": "payed",
        "product_title": "Курс \"Основы\"",
        "deal_cost": 9900,
        "deal_currency": "RUB",
        "payed_at": "2026-04-17 10:00:00"
    }
}
encoded = base64.b64encode(json.dumps(deal).encode()).decode()
r = requests.post(f"{base}/deals",
                  data={"action": "add", "key": key, "data": encoded})
print(r.json())
```

## 4. Webhook-приёмник (FastAPI) — лид в Bitrix24

```python
from fastapi import FastAPI, Request
import requests, os

app = FastAPI()

@app.post("/getcourse-hook")
async def hook(req: Request):
    p = await req.json()
    # Пример: при регистрации создаём лид в Bitrix24
    bx = os.environ["BITRIX_WEBHOOK_URL"].rstrip("/") + "/"
    requests.post(bx + "crm.lead.add", json={"fields": {
        "TITLE": f"Getcourse: регистрация {p.get('email')}",
        "NAME": p.get("first_name", ""),
        "EMAIL": [{"VALUE": p["email"], "VALUE_TYPE": "WORK"}],
        "SOURCE_ID": "GETCOURSE",
        "COMMENTS": f"Tags: {p.get('group_name', '')}",
    }})
    return {"ok": True}
```

## 5. Массовая проставка тега по списку email из CSV

```python
import csv, time
with open("emails.csv") as f:
    for row in csv.DictReader(f):
        data = {"user": {"email": row["email"], "group_name": ["промо-апрель"]},
                "system": {"refresh_if_exists": 1}}
        encoded = base64.b64encode(json.dumps(data).encode()).decode()
        requests.post(f"{base}/users",
                      data={"action": "add", "key": key, "data": encoded})
        time.sleep(1.1)   # безопасно ≤60 rpm
```
