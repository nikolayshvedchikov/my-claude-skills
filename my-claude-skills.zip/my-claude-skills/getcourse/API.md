# Getcourse API — справочник

## Базовая схема запроса (export)

`POST https://<account>.getcourse.ru/pl/api/account/users`

Тело (`application/x-www-form-urlencoded`):
```
key=<SECRET>
&params[created_at][from]=2026-01-01
&params[created_at][to]=2026-04-17
&status=paid
```

Ответ синхронный:
```json
{ "success": true,
  "info": { "export_id": 123456 },
  "error_message": null }
```

Через некоторое время:
```
GET https://<account>.getcourse.ru/pl/api/account/exports/123456?key=<SECRET>
```
Ответ:
```json
{ "success": true,
  "info": { "status": "done", "items": [...], "fields": [...] } }
```

## Users — создать/обновить

`POST /pl/api/users`
```
action=add
&key=<SECRET>
&data=<base64(user_json)>
```

Где `user_json` — структура:
```json
{
  "user": {
    "email": "ivanov@example.com",
    "first_name": "Иван",
    "last_name": "Иванов",
    "phone": "+79999999999",
    "addfields": {"utm_source": "google"},
    "group_name": ["Клиенты"]
  },
  "system": {"refresh_if_exists": 1, "partner_email": ""},
  "session": {"utm_source": "google"}
}
```

## Deals — создать заказ

`POST /pl/api/deals`
```json
{
  "user": {"email": "ivanov@example.com"},
  "system": {"refresh_if_exists": 1},
  "deal": {
    "deal_number": "2026-0001",
    "deal_status": "payed",
    "product_title": "Курс Python",
    "deal_cost": 19900,
    "deal_currency": "RUB"
  }
}
```

## Webhooks

В ЛК: `Настройки → Вебхуки → Добавить`. Триггеры — разные (регистрация, покупка, переход в группу).

Формат POST-body — JSON с полями, конфигурируется вами при создании webhook.

Проверка подписи — в заголовке `X-Signature` (HMAC-SHA256 по `SECRET_KEY`).

## Коды ошибок

| HTTP | Причина |
|---|---|
| 200 + success=false | Ошибка в логике запроса (email невалидный, нет тега, неверный SECRET) |
| 401 | Неверный SECRET_KEY или аккаунт |
| 429 | Слишком часто (5xx тоже бывают — ретрай) |
| 500 | Внутренняя — подождать и повторить |

## Типы экспорта

- `users` — все пользователи (email, имя, теги, даты)
- `deals` — заказы (с продуктами, суммами)
- `payments` — платежи
- `mail` — рассылки (отправлено, открыто, кликнуто)
- `forms` — отправленные формы
