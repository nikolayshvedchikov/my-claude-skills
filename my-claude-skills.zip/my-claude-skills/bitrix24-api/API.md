# Bitrix24 REST — справочник методов

## Базовый формат запроса (webhook)

```python
import requests, os
URL = os.getenv("BITRIX_WEBHOOK_URL").rstrip("/") + "/"
r = requests.post(URL + "crm.lead.list", json={
    "filter": {"STATUS_ID": "NEW"},
    "select": ["ID", "TITLE", "STATUS_ID", "DATE_CREATE"],
    "start": 0,
})
data = r.json()  # {"result": [...], "total": N, "next": 50}
```

## CRM

### Лиды (`crm.lead.*`)
- `crm.lead.list` — фильтр+выборка
- `crm.lead.get` (ID)
- `crm.lead.add` (fields)
- `crm.lead.update` (ID, fields)
- `crm.lead.delete` (ID)

Ключевые поля: `TITLE, NAME, LAST_NAME, PHONE, EMAIL, STATUS_ID, SOURCE_ID, ASSIGNED_BY_ID, OPPORTUNITY, CURRENCY_ID, UF_*`

### Сделки (`crm.deal.*`)
Аналогично лидам + `STAGE_ID`, `CATEGORY_ID` (воронка), `COMPANY_ID`, `CONTACT_IDS`.

### Контакты/Компании
`crm.contact.*`, `crm.company.*` — те же CRUD-паттерны.

### Пользовательские поля
- `crm.lead.userfield.list/add/update/delete`
- Имя начинается с `UF_CRM_`, идентификатор (`FIELD_NAME`) возвращается при создании.

## Задачи

- `tasks.task.list/get/add/update/delete`
- `task.commentitem.getlist/add`
- Поля: `TITLE, DESCRIPTION, DEADLINE, RESPONSIBLE_ID, CREATED_BY, GROUP_ID`

## Пользователи

- `user.get` (filter: `ACTIVE, NAME, EMAIL`)
- `user.current` — текущий пользователь по токену
- `user.search` — поиск по ФИО/email

## Диск (Bitrix24.Drive)

- `disk.folder.getchildren` (id)
- `disk.file.get` (id), `disk.file.getExternalLink`
- `disk.folder.uploadfile` (id, fileContent: base64)

## Batch

```python
r = requests.post(URL + "batch", json={
    "halt": 0,
    "cmd": {
        "leads": "crm.lead.list?filter[STATUS_ID]=NEW&select[]=ID",
        "deals": "crm.deal.list?filter[STAGE_ID]=NEW&select[]=ID",
    }
})
# r.json()["result"]["result"]["leads"] — массив
```
До 50 команд; результат каждой — по своему ключу; поддерживает `$result[alias][key]` для переиспользования.

## События

- `events.register` — глобально подписать приложение
- `event.bind(event, handler)` — внешний URL для исходящего вебхука
- События: `ONCRMLEADADD`, `ONCRMDEALUPDATE`, `ONTASKADD` и т.д.

## Коды ошибок

| HTTP | Значение |
|---|---|
| 401 | invalid_token / expired_token — обновить через refresh |
| 403 | insufficient_scope — добавить scope в OAuth |
| 503 | QUERY_LIMIT_EXCEEDED — ждать 1 сек, ретрай |
| 400 | ERROR_METHOD_NOT_FOUND / неверные параметры |
