---
name: bitrix24-api
description: Работа с Bitrix24 REST API — вебхуки, OAuth2, CRM (лиды/сделки/контакты), задачи, пользователи, батчинг. Используй, когда нужно получать/создавать/обновлять данные на портале Bitrix24 через API. Ключи хранятся в .env (BITRIX_WEBHOOK_URL или BITRIX_CLIENT_ID/SECRET).
---

# Bitrix24 REST API

## Когда применять скилл

- Получить/создать/обновить лид, сделку, контакт, компанию, задачу, пользователя
- Выгрузить историю действий, события, комментарии
- Массовые операции (batch, списки, фильтры)
- Работа с UserField (UF_*) и каталогом товаров
- События (`events`) и исходящие вебхуки
- Прикрепление файлов из Bitrix24.Диск

## Аутентификация

Два режима, **используй тот, который настроен в `.env`**:

### 1. Входящий вебхук (Inbound webhook) — быстрый путь
```
BITRIX_WEBHOOK_URL=https://<portal>.bitrix24.ru/rest/<user_id>/<webhook_token>/
```
Запрос: `POST {BITRIX_WEBHOOK_URL}{method}` с JSON body.

### 2. OAuth2 — для тиражного приложения
```
BITRIX_CLIENT_ID=app.xxxxxxxx
BITRIX_CLIENT_SECRET=...
BITRIX_PORTAL_DOMAIN=<portal>.bitrix24.ru
```
Поток: получаем `access_token` через `/oauth/authorize` + `/oauth/token`, обновляем по `refresh_token` (срок токена — 1 час).

## Основные методы (см. API.md для деталей)

- `crm.lead.*`, `crm.deal.*`, `crm.contact.*`, `crm.company.*`
- `tasks.task.*`, `task.commentitem.*`
- `user.get`, `user.current`, `user.search`
- `disk.folder.*`, `disk.file.*`
- `batch` (до 50 команд за один запрос)
- `events.register`, `event.bind`

## Правила и ограничения

- **Rate limit**: 2 запроса/сек на вебхук; при превышении — HTTP 503. Используй `batch`.
- Все даты — ISO8601 в часовом поясе портала.
- Поля с `UF_` — пользовательские; `UF_CRM_*` — в CRM.
- Пагинация: `start=0`, ответ содержит `next` — повторяй, пока `next` присутствует.
- Для удаления — отдельный метод `*.delete`, **перед ним подтверждай у пользователя**.

## Ссылки на документацию

- REST overview: https://apidocs.bitrix24.com/
- Русская дока: https://dev.1c-bitrix.ru/rest_help/
- CRM: https://apidocs.bitrix24.com/api-reference/crm/
- Tasks: https://apidocs.bitrix24.com/api-reference/tasks/
- Batch: https://apidocs.bitrix24.com/api-reference/how-to-call-rest-api/batch.html

## Клиентские библиотеки

- Python: `pip install fast-bitrix24` — https://github.com/leshchenko1979/fast_bitrix24 (рекомендуется, есть async + автопагинация + rate-limit)
- Python: `pip install bitrix24-rest` — https://github.com/akopkesheshyan/bitrix24-python-rest
- Node.js: `npm install @2bad/bitrix` — https://github.com/2BAD/bitrix
- PHP (официальный): https://github.com/bitrix24/b24phpsdk

## Типовой план работы

1. Прочесть задачу, уточнить: портал, тип сущности, фильтры.
2. Собрать body: `filter`, `select`, `order`, `start`.
3. Вызвать `crm.<entity>.list`; при большом объёме — `batch` c раундами по 50.
4. Показать пользователю 3–5 первых записей для подтверждения.
5. Делать `update`/`add`/`delete` только после явного подтверждения.

## Безопасные дефолты

- Никогда не коммить `.env` с реальным `BITRIX_WEBHOOK_URL` — это даёт полный доступ к порталу.
- Перед `delete` — dry-run: показать, что именно удалится.
- Логгировать все исходящие POST в отдельный файл (не в репо).
