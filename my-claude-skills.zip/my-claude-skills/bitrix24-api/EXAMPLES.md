# Bitrix24 REST — типовые примеры

## 0. Установка зависимостей
```bash
pip install requests python-dotenv fast-bitrix24
```

## 1. Получить все новые лиды за сегодня (webhook)

```python
import os, datetime
from dotenv import load_dotenv
from fast_bitrix24 import Bitrix

load_dotenv()
b = Bitrix(os.getenv("BITRIX_WEBHOOK_URL"))

today = datetime.date.today().isoformat()
leads = b.get_all("crm.lead.list", params={
    "filter": {">=DATE_CREATE": f"{today}T00:00:00"},
    "select": ["ID", "TITLE", "STATUS_ID", "PHONE", "EMAIL"],
})
print(f"Новых лидов: {len(leads)}")
```

## 2. Создать сделку и связать с существующим контактом
```python
deal_id = b.call("crm.deal.add", {
    "fields": {
        "TITLE": "Консультация от бота",
        "CONTACT_ID": 12345,
        "CATEGORY_ID": 0,
        "STAGE_ID": "NEW",
        "OPPORTUNITY": 50000,
        "CURRENCY_ID": "RUB",
        "ASSIGNED_BY_ID": 1,
    }
})
```

## 3. Batch — получить лид + его активности за один HTTP-запрос
```python
res = b.call_batch({
    "halt": 0,
    "cmd": {
        "lead":       f"crm.lead.get?id=12345",
        "activities": f"crm.activity.list?filter[OWNER_ID]=12345&filter[OWNER_TYPE_ID]=1",
    },
})
lead = res["lead"]
activities = res["activities"]
```

## 4. OAuth2-токен (для приложений marketplace)
```python
import requests, os
r = requests.post(
    f"https://oauth.bitrix.info/oauth/token/",
    params={
        "grant_type": "authorization_code",
        "client_id": os.getenv("BITRIX_CLIENT_ID"),
        "client_secret": os.getenv("BITRIX_CLIENT_SECRET"),
        "code": CODE_FROM_REDIRECT,
    },
)
tok = r.json()  # {"access_token", "refresh_token", "expires_in", "domain", ...}
```

## 5. Обновить кастомное поле массово (пагинация + batch)
Сценарий: по списку сделок проставить `UF_CRM_1234567890 = "Y"`.
```python
for deal in b.get_all("crm.deal.list", {"filter": {"STAGE_ID": "NEW"}, "select": ["ID"]}):
    b.call("crm.deal.update", {"id": deal["ID"], "fields": {"UF_CRM_1234567890": "Y"}})
# fast_bitrix24 автоматически группирует в batch и соблюдает rate-limit
```
