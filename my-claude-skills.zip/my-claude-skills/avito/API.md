# Avito API — справочник

## Базовый URL

`https://api.avito.ru`

Заголовки для запросов:
```
Authorization: Bearer <access_token>
Content-Type: application/json
```

## Auth

### POST /token — client_credentials
Возвращает `access_token` (24ч).

## Items — объявления

| Метод | URL | Что |
|---|---|---|
| GET | `/core/v1/items` | список (пагинация `?per_page=&page=`, фильтры `?status=active`) |
| GET | `/core/v1/items/{item_id}` | получить 1 объявление |
| GET | `/core/v1/accounts/{user_id}/items/{item_id}/stats` | статистика |

## Messenger v2/v3

| Метод | URL | Что |
|---|---|---|
| GET | `/messenger/v2/accounts/{user_id}/chats` | список чатов (unread_only, limit, offset) |
| GET | `/messenger/v3/accounts/{user_id}/chats/{chat_id}/messages/` | история |
| POST | `/messenger/v1/accounts/{user_id}/chats/{chat_id}/messages` | отправить |
| POST | `/messenger/v1/accounts/{user_id}/chats/{chat_id}/read` | пометить прочитанным |
| POST | `/messenger/v1/webhook` | подписаться на события |

Payload отправки:
```json
{ "message": { "text": "Здравствуйте, доступно, готов к показу" }, "type": "text" }
```

## Statistics

| Метод | URL |
|---|---|
| POST | `/stats/v1/accounts/{user_id}/items` |

Body:
```json
{ "dateFrom": "2026-04-01", "dateTo": "2026-04-17",
  "fields": ["uniqViews", "uniqContacts", "uniqFavorites"],
  "itemIds": [123, 456], "periodGrouping": "day" }
```

## Отзывы

| Метод | URL |
|---|---|
| GET | `/ratings/v1/reviews` | список отзывов |
| POST | `/ratings/v1/reviews/{review_id}/answer` | ответить |

## Коды ошибок

| HTTP | Что делать |
|---|---|
| 401 | Перезапросить токен |
| 403 | Не хватает прав (scope) — проверить настройки приложения |
| 429 | Rate limit — экспоненциальный ретрай |
| 400 | Валидация — проверить body |
