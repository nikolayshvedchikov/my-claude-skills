---
name: avito
description: Работа с Avito.ru через официальный API — OAuth2 client_credentials, управление объявлениями, Messenger API для диалогов с покупателями, статистика просмотров, автозагрузка XML-фида, отзывы. Credentials — в .env (AVITO_CLIENT_ID / AVITO_CLIENT_SECRET / AVITO_USER_ID).
---

# Avito.ru API

## Когда применять

- Получить список своих объявлений, статистику, звонки, отзывы
- Отвечать в чатах (Messenger API)
- Загружать объявления через XML-фид (автозагрузка)
- Получать и закрывать обращения по объявлениям
- Управлять параметрами тарифов продвижения

## Аутентификация

Только **OAuth2 client credentials** (серверный поток):

```
AVITO_CLIENT_ID=
AVITO_CLIENT_SECRET=
AVITO_USER_ID=            # идентификатор вашего кабинета (для некоторых endpoint)
```

Получение ID/секрета: Личный кабинет → Настройки → API → Создать приложение.

Получение токена:
```bash
curl -X POST https://api.avito.ru/token \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "grant_type=client_credentials&client_id=$CID&client_secret=$CSEC"
# → {"access_token":"...", "expires_in":86400, "token_type":"Bearer"}
```

Токен живёт 24 часа; кэшировать локально.

## Ключевые возможности

### 1. Объявления (Items)
- `GET /core/v1/items` — список
- `GET /core/v1/items/{item_id}` — одно объявление
- Загрузка/редактирование новых — через XML-фид (автозагрузка), **не** через REST (ограничение Avito)

### 2. Messenger API
- `GET /messenger/v2/accounts/{user_id}/chats` — список чатов
- `POST /messenger/v1/accounts/{user_id}/chats/{chat_id}/messages` — отправить сообщение
- `GET /messenger/v3/accounts/{user_id}/chats/{chat_id}/messages/` — история
- Webhooks — подписка на новые сообщения

### 3. Статистика
- `GET /stats/v1/accounts/{user_id}/items` — просмотры/контакты за период

### 4. Автозагрузка
- Вы публикуете XML по своему URL; Avito забирает каждые 30–60 минут.
- Формат: https://autoload.avito.ru/format/ (по категориям)

## Rate limits

- Messenger: 1 сообщение/сек на чат, 1000 сообщений/сутки на аккаунт
- REST: 5 rps, 500 req/час

## Ссылки

- Developers portal: https://developers.avito.ru/
- API reference: https://developers.avito.ru/api-catalog
- Автозагрузка: https://autoload.avito.ru/format/
- Messenger docs: https://developers.avito.ru/api-catalog/messenger

## Клиентские библиотеки

Официальных SDK от Avito нет (на апрель 2026). Использовать обычный `requests`/`httpx`.
Community-обёртки (проверять перед использованием):
- Python: https://github.com/avito-tech (иногда появляются примеры)
- Gist-ы и wrapper'ы — не трекаем в этом скилле

## Типовой план работы

1. Получить/обновить токен (кэш до истечения).
2. Запросить список объявлений → показать сводку.
3. Для действий с чатами — строго по одному; подтверждать текст ответа у пользователя.
4. При массовых загрузках — готовить XML-фид, а не бомбить REST.

## Безопасные дефолты

- Никогда не коммитить `AVITO_CLIENT_SECRET`.
- Ответы в Messenger отправлять только после явного подтверждения пользователем (контент + адресат).
- Ставить User-Agent с вашим app-именем (рекомендация Avito).
