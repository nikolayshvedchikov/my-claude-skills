# Avito — примеры

## 0. Зависимости

```bash
pip install requests python-dotenv tenacity
```

## 1. Получение токена с кэшем

```python
import os, time, json, pathlib, requests
from dotenv import load_dotenv
load_dotenv()

CACHE = pathlib.Path(".avito_token.json")

def get_token():
    if CACHE.exists():
        d = json.loads(CACHE.read_text())
        if d["expires_at"] > time.time() + 60:
            return d["access_token"]
    r = requests.post("https://api.avito.ru/token", data={
        "grant_type": "client_credentials",
        "client_id": os.environ["AVITO_CLIENT_ID"],
        "client_secret": os.environ["AVITO_CLIENT_SECRET"],
    }).json()
    CACHE.write_text(json.dumps({
        "access_token": r["access_token"],
        "expires_at": time.time() + r["expires_in"] - 60,
    }))
    return r["access_token"]
```

## 2. Список активных объявлений

```python
tok = get_token()
user = os.environ["AVITO_USER_ID"]
h = {"Authorization": f"Bearer {tok}"}
r = requests.get(f"https://api.avito.ru/core/v1/items",
                 params={"status": "active", "per_page": 100}, headers=h)
for it in r.json().get("resources", []):
    print(it["id"], it["title"], it["price"])
```

## 3. Ответить на новое сообщение (подтверждаем у юзера!)

```python
chats = requests.get(
    f"https://api.avito.ru/messenger/v2/accounts/{user}/chats",
    params={"unread_only": "true"}, headers=h).json()
for c in chats.get("chats", []):
    print("Новый чат:", c["id"], "по объявлению", c["context"]["value"]["title"])
# → подтверждение от пользователя (текст ответа)
reply = "Здравствуйте! Да, доступно."
requests.post(
    f"https://api.avito.ru/messenger/v1/accounts/{user}/chats/{c['id']}/messages",
    headers=h,
    json={"message": {"text": reply}, "type": "text"})
```

## 4. Статистика просмотров за 30 дней

```python
from datetime import date, timedelta
to_d = date.today().isoformat()
from_d = (date.today() - timedelta(days=30)).isoformat()
r = requests.post(
    f"https://api.avito.ru/stats/v1/accounts/{user}/items",
    headers=h,
    json={"dateFrom": from_d, "dateTo": to_d,
          "fields": ["uniqViews","uniqContacts"],
          "periodGrouping": "day", "itemIds": [...]},
).json()
```

## 5. Webhook для входящих сообщений (минимальный HTTP-сервер)

```python
from fastapi import FastAPI, Request
app = FastAPI()

@app.post("/avito-hook")
async def hook(req: Request):
    payload = await req.json()
    # payload["payload"]["value"] — объект сообщения
    # обработка: сохранить, уведомить Claude/менеджера
    return {"ok": True}
```
Регистрация: `POST /messenger/v1/webhook  {"url":"https://your.host/avito-hook"}`
