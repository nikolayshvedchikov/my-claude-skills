# 1С:Фреш — примеры

## 0. Зависимости
```bash
pip install requests python-dotenv
```

## 1. Список контрагентов (OData, JSON)

```python
import os, requests
from dotenv import load_dotenv
load_dotenv()

url = os.environ["ONEC_FRESH_DB_URL"].rstrip("/") + "/odata/standard.odata/Catalog_Контрагенты"
r = requests.get(url, params={
    "$format": "json",
    "$top": 100,
    "$select": "Ref_Key,Код,Наименование,ИНН",
    "$filter": "IsFolder eq false",
}, auth=(os.environ["ONEC_FRESH_DB_LOGIN"], os.environ["ONEC_FRESH_DB_PASSWORD"]))
for x in r.json()["value"]:
    print(x["Код"], x["Наименование"])
```

## 2. Создать контрагента

```python
payload = {
    "Description": "ООО Ромашка",
    "НаименованиеПолное": "Общество с ограниченной ответственностью \"Ромашка\"",
    "ИНН": "7701234567",
    "КПП": "770101001",
    "ЮридическоеФизическоеЛицо": "ЮридическоеЛицо",
}
r = requests.post(url + "?$format=json", json=payload,
    auth=(os.environ["ONEC_FRESH_DB_LOGIN"], os.environ["ONEC_FRESH_DB_PASSWORD"]))
print(r.status_code, r.json())
```

## 3. Создать пользователя абонента через Portal API

```python
import os, requests
base = os.environ["ONEC_FRESH_BASE_URL"].rstrip("/")
r = requests.post(f"{base}/a/sm/hs/usr/users", json={
    "login": "ivanov",
    "name": "Иванов Иван",
    "email": "ivanov@example.com",
    "role": "user",
}, auth=(os.environ["ONEC_FRESH_LOGIN"], os.environ["ONEC_FRESH_PASSWORD"]))
print(r.status_code, r.text)
```
**Важно:** точный путь `/a/sm/hs/usr/...` зависит от провайдера. На 1cfresh.com проверяйте документацию ЛК.

## 4. Выгрузка документов за месяц в CSV

```python
import csv, requests
params = {
    "$format": "json", "$top": 1000,
    "$filter": "Date ge datetime'2026-04-01T00:00:00' and Date lt datetime'2026-05-01T00:00:00'",
    "$select": "Number,Date,Контрагент/Description,СуммаДокумента",
    "$expand": "Контрагент",
}
r = requests.get(
    os.environ["ONEC_FRESH_DB_URL"].rstrip("/") + "/odata/standard.odata/Document_РеализацияТоваров",
    params=params,
    auth=(os.environ["ONEC_FRESH_DB_LOGIN"], os.environ["ONEC_FRESH_DB_PASSWORD"]))
with open("realizations.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["Номер", "Дата", "Контрагент", "Сумма"])
    for d in r.json()["value"]:
        w.writerow([d["Number"], d["Date"], d["Контрагент"]["Description"], d["СуммаДокумента"]])
```

## 5. Запрос резервной копии

```python
r = requests.get(f"{base}/a/sm/hs/apps/{app_id}/backup",
                 auth=(os.environ["ONEC_FRESH_LOGIN"], os.environ["ONEC_FRESH_PASSWORD"]))
# { "backup_url": "https://..." }  — ссылка действует ограниченное время
```
